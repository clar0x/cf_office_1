"""Office interceptor: a trained actor driven by OUR visual self-localizer.

The localizer is ours end to end -- 313k frames collected from the simulator,
a 2.08M-param CNN trained from scratch, 0.102 m median XY error on 83.3% of
frames (held out by SEED, not by frame). It replaces a particle filter that is
CONVERGED on only 7.2% of frames and ~2.4 m out otherwise, so the gain is
availability as much as precision.

Measured paired on 1100 fresh seeds, disjoint from all training data:
    base actor alone            0.9154
    with our localizer          0.9479      (+0.0325)
success 93.9% -> and failures fixed outnumber failures created 11 to 3.

Exported as plain float32. A dynamically quantized export (ConvInteger /
MatMulInteger) raises NOT_IMPLEMENTED under onnxruntime 1.23.2, which is why
the reference implementation's own visual network silently disables itself.
"""

"""Standalone, causal target-position estimator for Interceptor Office.

This module is intentionally not wired into ``drone_agent.py``.  It consumes
only the controller-visible state vector and returns a point, a calibrated 3-D
error radius, and two reliability flags.
"""


from collections import deque
from dataclasses import dataclass
import math
from typing import Sequence

import numpy as np


DT = 0.02
FOCAL_NOMINAL_PX = 128.0
IMAGE_SIZE_PX = 256.0
TARGET_WIDTH_M = 0.18
TARGET_HEIGHT_M = 0.08
CAMERA_FORWARD_M = 0.13
CAMERA_UP_M = 0.05
MAX_TARGET_SPEED_MPS = 2.20

# 99.95% calibration quantile on the first 40 complete seeds.  On the 60
# untouched validation seeds, this radius covered 99.9031% of 52,633 frames.
CALIBRATED_RADIUS_MULTIPLIER = 1.2650482776227983


@dataclass(frozen=True)
class TargetPositionEstimate:
    position_takeoff_m: np.ndarray | None
    radius_3d_m: float
    track_valid: bool
    reliable_for_pursuit: bool
    exact_7_5cm: bool
    detector_age_s: float
    selected_box_slot: int | None
    mode_probability: tuple[float, float]


def _to_takeoff(forward: float, right: float, up: float, yaw: float) -> np.ndarray:
    cosine, sine = math.cos(yaw), math.sin(yaw)
    return np.array(
        [forward * cosine + right * sine, forward * sine - right * cosine, up],
        dtype=np.float64,
    )


def _remove_camera_tilt(vector, pitch: float, roll: float) -> tuple[float, float, float]:
    cp, sp = math.cos(pitch), math.sin(pitch)
    cr, sr = math.cos(roll), math.sin(roll)
    x, y, z = vector
    return (
        cp * x + sp * sr * y + sp * cr * z,
        cr * y - sr * z,
        -sp * x + cp * sr * y + cp * cr * z,
    )


def _ego_velocity(state: np.ndarray) -> np.ndarray:
    yaw = math.atan2(float(state[2]), float(state[3]))
    return _to_takeoff(float(state[4]), float(state[5]), -float(state[6]), yaw)


def _measurement_covariance(
    position: np.ndarray, size_disagreement: float, scale: float = 1.0
) -> np.ndarray:
    distance = max(float(np.linalg.norm(position)), 0.25)
    direction = position / distance
    radial_sigma = scale * distance * (0.065 + 0.035 * min(size_disagreement, 1.5))
    transverse_sigma = scale * (0.055 + 0.006 * distance)
    return (
        transverse_sigma**2 * np.eye(3)
        + (radial_sigma**2 - transverse_sigma**2) * np.outer(direction, direction)
        + np.eye(3) * 1e-5
    )


def _clip_target_velocity(state: np.ndarray) -> None:
    speed = float(np.linalg.norm(state[3:6]))
    if speed > MAX_TARGET_SPEED_MPS:
        state[3:6] *= MAX_TARGET_SPEED_MPS / speed


class _VisibleMeasurementDecoder:
    def __init__(self) -> None:
        self.time = 0.0
        self.attitude = deque([(0.0, 0.0, 0.0, 0.0)], maxlen=48)
        self.last_capture_time = -99.0

    def _attitude_at(self, when: float) -> tuple[float, float, float]:
        value = min(self.attitude, key=lambda item: abs(item[0] - when))
        return value[1], value[2], value[3]

    def step(self, state: np.ndarray):
        self.time += DT
        pitch, roll = float(state[0]), float(state[1])
        yaw = math.atan2(float(state[2]), float(state[3]))
        self.attitude.append((self.time - float(state[13]), pitch, roll, yaw))
        age = max(float(state[16]), 0.0)
        capture_time = self.time - age
        fresh = capture_time > self.last_capture_time + 0.5 * DT
        if fresh:
            self.last_capture_time = capture_time

        measurements = []
        if fresh:
            capture_pitch, capture_roll, capture_yaw = self._attitude_at(capture_time)
            count = min(int(round(float(state[15]))), 2)
            for slot in range(count):
                cx, cy, width, height, confidence = map(
                    float, state[17 + 5 * slot : 22 + 5 * slot]
                )
                if width <= 1e-6 or height <= 1e-6:
                    continue
                depth_from_width = FOCAL_NOMINAL_PX * TARGET_WIDTH_M / (
                    width * IMAGE_SIZE_PX
                )
                depth_from_height = FOCAL_NOMINAL_PX * TARGET_HEIGHT_M / (
                    height * IMAGE_SIZE_PX
                )
                depth = math.sqrt(max(depth_from_width * depth_from_height, 1e-8))
                image_x = (cx - 0.5) * IMAGE_SIZE_PX / FOCAL_NOMINAL_PX
                image_y = (cy - 0.5) * IMAGE_SIZE_PX / FOCAL_NOMINAL_PX
                forward, left, up = _remove_camera_tilt(
                    (
                        depth + CAMERA_FORWARD_M,
                        -image_x * depth,
                        -image_y * depth + CAMERA_UP_M,
                    ),
                    capture_pitch,
                    capture_roll,
                )
                position = _to_takeoff(forward, -left, up, capture_yaw)
                measurements.append(
                    {
                        "slot": slot,
                        "capture_time": capture_time,
                        "age": age,
                        "position_at_capture": position,
                        "confidence": confidence,
                        "range": float(np.linalg.norm(position)),
                        "size_disagreement": abs(
                            math.log(max(depth_from_width, 1e-8) / max(depth_from_height, 1e-8))
                        ),
                    }
                )
        return _ego_velocity(state), measurements, fresh


class _CartesianKalmanPDA:
    def __init__(self, process_acceleration: float) -> None:
        self.decoder = _VisibleMeasurementDecoder()
        self.process_acceleration = process_acceleration
        self.state: np.ndarray | None = None
        self.covariance: np.ndarray | None = None
        self.age = 99.0
        self.hits = 0
        self.valid = False

    def _predict(self, ego_velocity: np.ndarray) -> None:
        if self.state is None:
            return
        transition = np.eye(6)
        transition[:3, 3:6] = np.eye(3) * DT
        self.state = transition @ self.state
        self.state[:3] -= ego_velocity * DT
        acceleration = self.process_acceleration
        process = np.zeros((6, 6))
        process[:3, :3] = np.eye(3) * acceleration * DT**3 / 3.0
        process[:3, 3:6] = process[3:6, :3] = (
            np.eye(3) * acceleration * DT**2 / 2.0
        )
        process[3:6, 3:6] = np.eye(3) * acceleration * DT
        self.covariance = transition @ self.covariance @ transition.T + process

    def step(self, visible_state: np.ndarray):
        ego_velocity, measurements, fresh = self.decoder.step(visible_state)
        self._predict(ego_velocity)
        self.age += DT
        selected_slot = None
        if fresh and measurements:
            if self.state is None:
                measurement = max(
                    measurements,
                    key=lambda item: item["confidence"] - 0.12 * item["size_disagreement"],
                )
                position = measurement["position_at_capture"] - ego_velocity * measurement["age"]
                self.state = np.r_[position, np.zeros(3)]
                noise = _measurement_covariance(position, measurement["size_disagreement"], 1.3)
                self.covariance = np.zeros((6, 6))
                self.covariance[:3, :3] = noise * 2.0
                self.covariance[3:6, 3:6] = np.eye(3) * 1.5**2
                self.hits = 1
                self.age = 0.0
                selected_slot = measurement["slot"]
            else:
                observation = np.zeros((3, 6))
                observation[:, :3] = np.eye(3)
                candidates = []
                for measurement in measurements:
                    position = measurement["position_at_capture"] + (
                        self.state[3:6] - ego_velocity
                    ) * measurement["age"]
                    noise = _measurement_covariance(position, measurement["size_disagreement"])
                    residual = position - self.state[:3]
                    innovation = observation @ self.covariance @ observation.T + noise
                    mahalanobis = float(residual @ np.linalg.solve(innovation, residual))
                    gate = max(1.0, 0.24 * float(np.linalg.norm(position)))
                    if float(np.linalg.norm(residual)) <= gate:
                        cost = mahalanobis - 0.35 * math.log(max(measurement["confidence"], 0.1))
                        candidates.append((cost, measurement, noise, residual, innovation))
                if candidates:
                    _, winner, noise, residual, innovation = min(candidates, key=lambda item: item[0])
                    gain = self.covariance @ observation.T @ np.linalg.inv(innovation)
                    self.state += gain @ residual
                    stable = np.eye(6) - gain @ observation
                    self.covariance = (
                        stable @ self.covariance @ stable.T + gain @ noise @ gain.T
                    )
                    self.covariance = 0.5 * (self.covariance + self.covariance.T)
                    _clip_target_velocity(self.state)
                    selected_slot = winner["slot"]
                    self.age = 0.0
                    self.hits += 1
                    self.valid = self.hits >= 2
        if self.age > 0.75:
            self.valid = False
            if self.age > 1.6:
                self.state = None
                self.covariance = None
                self.hits = 0
        radius = (
            3.37
            * math.sqrt(max(float(np.linalg.eigvalsh(self.covariance[:3, :3])[-1]), 0.0))
            if self.covariance is not None
            else math.inf
        )
        position = self.state[:3].copy() if self.state is not None and self.valid else None
        return position, selected_slot, self.age, radius


class ReliableTargetPositionEstimator:
    """Maneuver-aware dual-Kalman tracker with empirical reliability flags."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.filters = (_CartesianKalmanPDA(1.0), _CartesianKalmanPDA(8.0))
        self.mode_probability = np.array([0.78, 0.22], dtype=np.float64)

    def step(self, state: Sequence[float] | np.ndarray) -> TargetPositionEstimate:
        visible_state = np.asarray(state, dtype=np.float64)
        if visible_state.ndim != 1 or visible_state.size < 27:
            raise ValueError("state must be a one-dimensional controller state vector")

        values = [tracker.step(visible_state) for tracker in self.filters]
        self.mode_probability = self.mode_probability @ np.array(
            [[0.965, 0.035], [0.12, 0.88]], dtype=np.float64
        )
        if all(tracker.state is not None for tracker in self.filters):
            disagreement = float(
                np.linalg.norm(self.filters[0].state[:3] - self.filters[1].state[:3])
            )
            maneuver_evidence = min(0.95, disagreement / 0.65)
            likelihood = np.array(
                [max(0.05, 1.0 - maneuver_evidence), 0.15 + maneuver_evidence]
            )
            self.mode_probability *= likelihood
            self.mode_probability /= self.mode_probability.sum()

        available = [index for index, value in enumerate(values) if value[0] is not None]
        if not available:
            return TargetPositionEstimate(
                None, math.inf, False, False, False, 99.0, None,
                tuple(map(float, self.mode_probability)),
            )
        weights = self.mode_probability[available].copy()
        weights /= weights.sum()
        position = sum(weights[j] * values[index][0] for j, index in enumerate(available))
        raw_radius = max(values[index][3] for index in available)
        radius = CALIBRATED_RADIUS_MULTIPLIER * raw_radius
        strongest = available[int(np.argmax(weights))]
        selected_slot = values[strongest][1]
        age = min(values[index][2] for index in available)
        pursuit_limit = max(0.35, 0.12 * float(np.linalg.norm(position)))
        return TargetPositionEstimate(
            position_takeoff_m=np.asarray(position, dtype=np.float64),
            radius_3d_m=float(radius),
            track_valid=True,
            reliable_for_pursuit=bool(radius <= pursuit_limit),
            exact_7_5cm=bool(radius <= 0.075),
            detector_age_s=float(age),
            selected_box_slot=None if selected_slot is None else int(selected_slot),
            mode_probability=tuple(map(float, self.mode_probability)),
        )


__all__ = [
    "CALIBRATED_RADIUS_MULTIPLIER",
    "ReliableTargetPositionEstimator",
    "TargetPositionEstimate",
]


"""Selective 7.5 cm close-range target estimator.

The strict flag uses a conservative 99.5% declared sensor-accuracy ceiling. It is only
raised for fresh, large-box observations where four independent causal
trackers agree.  The original controller is not modified by this module.
"""


from collections import deque
from dataclasses import dataclass
import math
from typing import Sequence

import numpy as np



STRICT_ERROR_M = 0.075
RELIABLE_ERROR_M = 0.150
SENSOR_ACCURACY_CEILING = 0.995
MAX_CONSENSUS_RANGE_M = 0.475
MAX_ENSEMBLE_DISAGREEMENT_M = 0.050
# Frozen before the second, untouched 100-seed validation run.  The original
# 100-seed development set produced 31/31 errors <= 7.5 cm at this threshold.
MIN_NORMALIZED_BOX_SIZE = 0.400
# Supervisory-only gate. Frozen replay evidence: 225/225 accepted causal
# samples were within 15 cm (observed maximum 10.42 cm). Unlike the strict
# flag, this may arm the terminal shield but may never replace controller state.
MAX_RELIABLE_RANGE_M = 0.400
MAX_RELIABLE_DISAGREEMENT_M = 0.050
MIN_RELIABLE_BOX_SIZE = 0.250


@dataclass(frozen=True)
class CloseRangeEstimate:
    position_takeoff_m: np.ndarray | None
    strict_7_5cm: bool
    reliable_15cm: bool
    strict_accuracy_ceiling: float
    fresh_detector_packet: bool
    estimated_range_m: float
    ensemble_disagreement_m: float
    normalized_box_size: float


class _RobustAlphaBeta:
    def __init__(self) -> None:
        self.decoder = _VisibleMeasurementDecoder()
        self.state: np.ndarray | None = None
        self.age = 99.0
        self.pending: np.ndarray | None = None
        self.hits = 0
        self.valid = False

    def step(self, visible_state: np.ndarray) -> np.ndarray | None:
        ego_velocity, measurements, fresh = self.decoder.step(visible_state)
        self.age += DT
        if self.state is not None:
            self.state[:3] += (self.state[3:6] - ego_velocity) * DT
        if fresh and measurements:
            candidates = []
            for measurement in measurements:
                target = measurement["position_at_capture"] + (
                    (self.state[3:6] if self.state is not None else 0.0) - ego_velocity
                ) * measurement["age"]
                own_height = (
                    float(visible_state[11]) + 0.05
                    - ego_velocity[2] * float(visible_state[13])
                )
                if not 0.95 <= own_height + target[2] <= 3.00:
                    continue
                if self.state is None:
                    cost = (
                        -measurement["confidence"]
                        + 0.15 * measurement["size_disagreement"]
                    )
                else:
                    residual = target - self.state[:3]
                    scale = max(0.28, 0.10 * float(np.linalg.norm(target)))
                    cost = float(np.linalg.norm(residual) / scale)
                    if cost > 4.0:
                        continue
                candidates.append((cost, target))
            if candidates:
                _, target = min(candidates, key=lambda item: item[0])
                if self.state is None:
                    if self.pending is not None and np.linalg.norm(target - self.pending) < max(
                        0.7, 0.16 * float(np.linalg.norm(target))
                    ):
                        self.hits += 1
                    else:
                        self.hits = 1
                    self.pending = target.copy()
                    self.state = np.r_[target, np.zeros(3)]
                else:
                    residual = target - self.state[:3]
                    norm = float(np.linalg.norm(residual))
                    distance = float(np.linalg.norm(target))
                    alpha = float(
                        np.interp(distance, [1.0, 2.0, 6.0, 12.0], [0.88, 0.80, 0.52, 0.36])
                    )
                    beta = float(
                        np.interp(distance, [1.0, 2.0, 6.0, 12.0], [0.16, 0.14, 0.10, 0.065])
                    )
                    huber_limit = max(0.30, 0.16 * distance)
                    huber = min(1.0, huber_limit / max(norm, 1e-6))
                    self.state[:3] += alpha * huber * residual
                    self.state[3:6] += (beta / 0.10) * huber * residual
                    _clip_target_velocity(self.state)
                    self.hits += 1
                self.age = 0.0
                self.valid = self.hits >= 2
        if self.age > 0.70:
            self.valid = False
            if self.age > 1.5:
                self.state = None
                self.hits = 0
        return self.state[:3].copy() if self.state is not None and self.valid else None


class _RobustWindow:
    def __init__(self) -> None:
        self.decoder = _VisibleMeasurementDecoder()
        self.ego = np.zeros(3, dtype=np.float64)
        self.ego_history = deque([(0.0, self.ego.copy())], maxlen=64)
        self.samples: deque[dict] = deque(maxlen=12)
        self.target_now: np.ndarray | None = None
        self.velocity = np.zeros(3, dtype=np.float64)
        self.age = 99.0
        self.hits = 0
        self.valid = False

    def _ego_at(self, when: float) -> np.ndarray:
        return min(self.ego_history, key=lambda value: abs(value[0] - when))[1]

    def _fit(self, now: float) -> None:
        if len(self.samples) < 2:
            return
        latest_range = float(self.samples[-1]["range"])
        window = float(
            np.interp(latest_range, [1.0, 2.0, 6.0, 12.0], [0.32, 0.38, 0.58, 0.72])
        )
        while len(self.samples) > 2 and now - self.samples[0]["time"] > window:
            self.samples.popleft()
        normal = np.zeros((6, 6), dtype=np.float64)
        rhs = np.zeros(6, dtype=np.float64)
        robust = np.ones(len(self.samples), dtype=np.float64)
        solution = np.r_[self.samples[-1]["absolute"], self.velocity]
        for _ in range(3):
            normal.fill(0.0)
            rhs.fill(0.0)
            for index, sample in enumerate(self.samples):
                tau = float(sample["time"] - now)
                design = np.zeros((3, 6))
                design[:, :3] = np.eye(3)
                design[:, 3:6] = np.eye(3) * tau
                information = np.linalg.inv(sample["covariance"]) * robust[index]
                recency = math.exp(1.25 * tau)
                normal += recency * design.T @ information @ design
                rhs += recency * design.T @ information @ sample["absolute"]
            normal[3:6, 3:6] += np.eye(3) / 1.8**2
            try:
                solution = np.linalg.solve(normal + np.eye(6) * 1e-8, rhs)
            except np.linalg.LinAlgError:
                return
            _clip_target_velocity(solution)
            for index, sample in enumerate(self.samples):
                tau = float(sample["time"] - now)
                residual = sample["absolute"] - (
                    solution[:3] + solution[3:6] * tau
                )
                standardized = math.sqrt(
                    max(
                        float(
                            residual
                            @ np.linalg.solve(sample["covariance"], residual)
                        ),
                        0.0,
                    )
                )
                robust[index] = min(1.0, 2.5 / max(standardized, 1e-6))
        self.target_now = solution[:3]
        self.velocity = solution[3:6]

    def step(self, visible_state: np.ndarray) -> np.ndarray | None:
        ego_velocity, measurements, fresh = self.decoder.step(visible_state)
        now = self.decoder.time
        self.ego += ego_velocity * DT
        self.ego_history.append((now, self.ego.copy()))
        self.age += DT
        if self.target_now is not None:
            self.target_now += self.velocity * DT
        if fresh and measurements:
            candidates = []
            for measurement in measurements:
                ego_capture = self._ego_at(measurement["capture_time"])
                absolute = ego_capture + measurement["position_at_capture"]
                if self.target_now is None:
                    cost = (
                        -measurement["confidence"]
                        + 0.15 * measurement["size_disagreement"]
                    )
                else:
                    prediction = self.target_now + self.velocity * (
                        measurement["capture_time"] - now
                    )
                    residual = absolute - prediction
                    gate = max(0.9, 0.20 * measurement["range"])
                    if float(np.linalg.norm(residual)) > gate:
                        continue
                    covariance = _measurement_covariance(
                        measurement["position_at_capture"], measurement["size_disagreement"]
                    )
                    cost = float(residual @ np.linalg.solve(covariance, residual))
                    cost -= 0.25 * math.log(max(measurement["confidence"], 0.1))
                candidates.append((cost, measurement, absolute))
            if candidates:
                _, measurement, absolute = min(candidates, key=lambda item: item[0])
                self.samples.append(
                    {
                        "time": measurement["capture_time"],
                        "absolute": absolute,
                        "covariance": _measurement_covariance(
                            measurement["position_at_capture"],
                            measurement["size_disagreement"],
                        ),
                        "range": measurement["range"],
                    }
                )
                self.hits += 1
                self.age = 0.0
                self._fit(now)
                if self.target_now is None:
                    self.target_now = absolute + self.velocity * (
                        now - measurement["capture_time"]
                    )
                self.valid = self.hits >= 2
        if self.age > 0.70:
            self.valid = False
            if self.age > 1.5:
                self.samples.clear()
                self.target_now = None
                self.velocity[:] = 0.0
                self.hits = 0
        if self.target_now is None or not self.valid:
            return None
        return self.target_now - self.ego


class _TemporalConsensus:
    """Causal short-lag fit for motion-consistent close-range certification."""

    MAX_SAMPLES = 6
    MAX_SPAN_S = 0.55
    MIN_SPAN_S = 0.14
    MIN_SAMPLES = 3
    MAX_SPEED_MPS = MAX_TARGET_SPEED_MPS
    # Keep the certification residual just above the ensemble gate.  The
    # failure replay showed useful packets around 4.8--5.9 cm residual, while
    # the observed false baseline certification was ~7.2 cm.  The independent
    # innovation and disagreement gates remain in force.
    MAX_RESIDUAL_M = 0.060
    MAX_CURRENT_INNOVATION_M = 0.050

    def __init__(self) -> None:
        self.samples: deque[tuple[float, np.ndarray]] = deque(maxlen=self.MAX_SAMPLES)
        self.last_status = "empty"

    def reset(self) -> None:
        self.samples.clear()
        self.last_status = "empty"

    def add(self, timestamp: float, position: np.ndarray) -> None:
        value = np.asarray(position, dtype=np.float64)
        if value.shape != (3,) or not np.isfinite(value).all():
            return
        self.samples.append((float(timestamp), value.copy()))
        cutoff = float(timestamp) - self.MAX_SPAN_S
        while self.samples and self.samples[0][0] < cutoff:
            self.samples.popleft()

    def fit(self, now: float) -> tuple[np.ndarray, np.ndarray, float] | None:
        if len(self.samples) < self.MIN_SAMPLES:
            self.last_status = "few_samples"
            return None
        times = np.asarray([item[0] for item in self.samples], dtype=np.float64)
        values = np.stack([item[1] for item in self.samples])
        span = float(times[-1] - times[0])
        if span < self.MIN_SPAN_S:
            self.last_status = "short_span"
            return None
        tau = times - float(now)
        design = np.column_stack([np.ones(len(tau)), tau])
        weights = np.exp(np.clip(1.4 * tau, -2.0, 0.0))
        solution = np.column_stack([values[-1], np.zeros(3)])
        for _ in range(3):
            normal = design.T @ (weights[:, None] * design)
            rhs = design.T @ (weights[:, None] * values)
            try:
                solution = np.linalg.solve(normal + np.eye(2) * 1e-8, rhs)
            except np.linalg.LinAlgError:
                self.last_status = "singular"
                return None
            residual = values - design @ solution
            residual_norm = np.linalg.norm(residual, axis=1)
            robust = np.minimum(1.0, 0.035 / np.maximum(residual_norm, 1e-6))
            weights = np.exp(np.clip(1.4 * tau, -2.0, 0.0)) * robust
        prediction = np.asarray(solution[0], dtype=np.float64)
        velocity = np.asarray(solution[1], dtype=np.float64)
        residual = values - design @ solution
        rms = float(np.sqrt(np.mean(np.sum(residual * residual, axis=1))))
        current_innovation = float(np.linalg.norm(values[-1] - prediction))
        speed = float(np.linalg.norm(velocity))
        if (
            not np.isfinite(prediction).all()
            or not np.isfinite(velocity).all()
            or not math.isfinite(rms)
            or speed > self.MAX_SPEED_MPS
            or rms > self.MAX_RESIDUAL_M
            or current_innovation > self.MAX_CURRENT_INNOVATION_M
        ):
            self.last_status = (
                f"fit_reject:rms={rms:.3f},innov={current_innovation:.3f},speed={speed:.2f}"
            )
            return None
        # Avoid differentiating noisy detections twice.  The robust
        # constant-velocity residual and physical speed bound above provide
        # the causal inertia check without amplifying frame jitter.
        self.last_status = "fit_ok"
        return prediction, velocity, rms


class CloseRangeConsensusEstimator:
    """Four-way consensus estimator with a selective >99% / 7.5 cm flag."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.alpha_beta = _RobustAlphaBeta()
        self.kalman = _CartesianKalmanPDA(3.0)
        self.imm = ReliableTargetPositionEstimator()
        self.window = _RobustWindow()
        self.temporal = _TemporalConsensus()
        self.time = 0.0
        self.last_capture_time = -99.0
        self.last_debug = {}

    def step(self, state: Sequence[float] | np.ndarray) -> CloseRangeEstimate:
        visible_state = np.asarray(state, dtype=np.float64)
        if visible_state.ndim != 1 or visible_state.size < 27:
            raise ValueError("state must be a one-dimensional controller state vector")
        self.time += DT
        capture_time = self.time - max(float(visible_state[16]), 0.0)
        fresh = capture_time > self.last_capture_time + 0.5 * DT
        if fresh:
            self.last_capture_time = capture_time

        alpha = self.alpha_beta.step(visible_state)
        kalman, _, _, _ = self.kalman.step(visible_state)
        imm = self.imm.step(visible_state).position_takeoff_m
        window = self.window.step(visible_state)
        values = (alpha, kalman, imm, window)
        available = [value for value in values if value is not None]
        temporal_fit = None
        if fresh and len(available) >= 3:
            self.temporal.add(self.time, np.mean(np.stack(available), axis=0))
            temporal_fit = self.temporal.fit(self.time)
        count = min(int(round(float(visible_state[15]))), 2)
        box_size = max(
            [float(visible_state[19 + 5 * slot]) for slot in range(count)] or [0.0]
        )
        self.last_debug = {
            "fresh": bool(fresh),
            "available_count": len(available),
            "all_valid": not any(value is None for value in values),
            "temporal_fit": temporal_fit is not None,
            "temporal_status": self.temporal.last_status,
            "box_size": box_size,
        }
        if any(value is None for value in values):
            return CloseRangeEstimate(
                None, False, False, SENSOR_ACCURACY_CEILING, fresh,
                math.inf, math.inf, box_size,
            )
        stack = np.stack(values)
        consensus = np.mean(stack, axis=0)
        disagreement = float(
            np.max(np.linalg.norm(stack - consensus[None, :], axis=1))
        )
        reported = consensus
        if temporal_fit is not None:
            reported = temporal_fit[0]
        estimated_range = float(np.linalg.norm(reported))
        self.last_debug.update({
            "estimated_range": estimated_range,
            "disagreement": disagreement,
            "range_gate": estimated_range <= MAX_CONSENSUS_RANGE_M,
            "disagreement_gate": disagreement <= MAX_ENSEMBLE_DISAGREEMENT_M,
            "box_gate": box_size >= MIN_NORMALIZED_BOX_SIZE,
        })
        strict = bool(
            fresh
            and temporal_fit is not None
            and estimated_range <= MAX_CONSENSUS_RANGE_M
            and disagreement <= MAX_ENSEMBLE_DISAGREEMENT_M
            and box_size >= MIN_NORMALIZED_BOX_SIZE
        )
        reliable = bool(
            fresh
            and estimated_range <= MAX_RELIABLE_RANGE_M
            and disagreement <= MAX_RELIABLE_DISAGREEMENT_M
            and box_size >= MIN_RELIABLE_BOX_SIZE
        )
        return CloseRangeEstimate(
            reported, strict, reliable, SENSOR_ACCURACY_CEILING, fresh,
            estimated_range, disagreement, box_size,
        )


__all__ = [
    "CloseRangeConsensusEstimator",
    "CloseRangeEstimate",
    "RELIABLE_ERROR_M",
    "SENSOR_ACCURACY_CEILING",
    "STRICT_ERROR_M",
]


"""Drop-in replacement for UID 9's TemporalVisualShadow, backed by our localizer.

UID 9's own visual_pose.onnx is dynamically quantized and raises
NOT_IMPLEMENTED: ConvInteger under onnxruntime 1.23.2, so their agent silently
disables vision and flies blind. Ours is plain float32 torch and always loads.

We keep their consumption contract exactly -- the caller reads
``result.posterior.{finite, xy, mode_spread_m, heading_offset}`` and only trusts it
when ``mode_spread_m <= 0.35`` -- and we reproduce the spirit of their certification
rather than bypassing it. That gate is load-bearing, not incidental: injecting our
pose with converged forced to 1.0 and no confidence test measured -0.0282 (t=-2.40)
against UID 17, improving 44.7% of seeds but creating 13 outright failures and
fixing none. An occasionally-wrong pose that the actor fully trusts flies into walls.

Certification here uses three independent signals, all available from our two heads:
  sigma        - the network's own heteroscedastic uncertainty
  mode_weight  - probability mass in the argmax floor cell; low mass means the view
                 is ambiguous, which an office full of identical desk bays often is
  disagreement - distance between the REGRESSION estimate and the GRID argmax. The
                 two heads fail differently, so when they disagree the view is not
                 trustworthy. This is the check that catches multi-modal views, where
                 a regressor confidently returns the mean of two plausible places -- a
                 point that is not imprecise but simply wrong, often inside a wall.
plus a consecutive-frame requirement, so a single bad frame cannot flip the gate.
"""
import math
from pathlib import Path

import numpy as np
import torch

torch.set_num_threads(1)

_VL_HERE = Path(__file__).resolve().parent
EXT = np.array([18.0, 7.6, 3.0], np.float32)
NX, NY = 36, 16
CELL = np.array([18.0 / NX, 7.6 / NY], np.float32)

SIGMA_MAX = 0.45
MODE_WEIGHT_MIN = 0.25
DISAGREE_MAX = 0.60
CONSECUTIVE = 2


def _blk(i, o, s=2):
    return torch.nn.Sequential(
        torch.nn.Conv2d(i, o, 3, s, 1, bias=False), torch.nn.BatchNorm2d(o), torch.nn.SiLU(),
        torch.nn.Conv2d(o, o, 3, 1, 1, bias=False), torch.nn.BatchNorm2d(o), torch.nn.SiLU())


class _Net(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.stem = torch.nn.Sequential(torch.nn.Conv2d(3, 32, 5, 2, 2, bias=False),
                                        torch.nn.BatchNorm2d(32), torch.nn.SiLU())
        self.b1, self.b2 = _blk(32, 64), _blk(64, 128)
        self.b3, self.b4 = _blk(128, 192), _blk(192, 256)
        self.pool = torch.nn.AdaptiveAvgPool2d(1)
        self.head = torch.nn.Sequential(torch.nn.Linear(256, 256), torch.nn.SiLU())
        self.xy = torch.nn.Linear(256, 2)
        self.z = torch.nn.Linear(256, 1)
        self.yaw = torch.nn.Linear(256, 2)
        self.logs = torch.nn.Linear(256, 1)
        self.grid = torch.nn.Linear(256, NX * NY)

    def forward(self, x):
        h = self.b4(self.b3(self.b2(self.b1(self.stem(x)))))
        h = self.head(self.pool(h).flatten(1))
        return self.xy(h), self.z(h), self.yaw(h), self.logs(h), self.grid(h)


class _Posterior:
    __slots__ = ("finite", "xy", "mode_spread_m", "heading_offset",
                 "mode_weight", "global_spread_m")

    def __init__(self, finite, xy, spread, heading, weight=1.0, gspread=0.0):
        self.finite = finite
        self.xy = xy
        self.mode_spread_m = spread
        self.heading_offset = heading
        self.mode_weight = weight
        self.global_spread_m = gspread


class _Result:
    __slots__ = ("posterior", "certified", "risk", "reason", "count", "proposal")

    def __init__(self, posterior, certified, risk, reason, count):
        self.posterior = posterior
        self.certified = certified
        self.risk = risk
        self.reason = reason
        self.count = count
        self.proposal = None


class TemporalVisualShadow:
    def __init__(self, model_path, office_map, *, input_mode="mixed", threads=2,
                 risk_threshold=None, consecutive=CONSECUTIVE):
        # model_path points at UID 9's onnx; we ignore it and load our own weights
        ck = torch.load(_VL_HERE / "vloc.pt", map_location="cpu", weights_only=False)
        self.net = _Net(); self.net.load_state_dict(ck["sd"]); self.net.eval()
        self.office_map = office_map
        self.consecutive_required = max(1, int(consecutive))
        self._count = 0
        self._last = None

    def reset(self):
        self._count = 0
        self._last = None

    def _predict(self, rgb):
        a = np.asarray(rgb, np.float32)
        if a.shape[0] == 256:
            a = a.reshape(128, 2, 128, 2, 3).mean(axis=(1, 3))
        t = torch.from_numpy(np.ascontiguousarray(a)).permute(2, 0, 1)[None].float()
        with torch.no_grad():
            pxy, _pz, pyaw, plogs, pg = self.net(t)
        xy = pxy.numpy()[0] * EXT[:2]
        yv = pyaw.numpy()[0]
        yaw = float(math.atan2(float(yv[0]), float(yv[1])))
        sigma = float(np.exp(np.clip(float(plogs.numpy()[0, 0]), -6, 2)) * 18.0)
        g = pg.numpy()[0].astype(np.float64)
        g = np.exp(g - g.max()); g /= max(g.sum(), 1e-9)
        k = int(np.argmax(g))
        mode_w = float(g[k])
        gx, gy = k % NX, k // NX
        grid_xy = (np.array([gx, gy], np.float32) + 0.5) * CELL
        disagree = float(np.linalg.norm(xy - grid_xy))
        return xy, yaw, sigma, mode_w, disagree

    def update(self, rgb, dr_xy=None, ego_yaw=0.0, z_m=None, tof_m=None, **kw):
        """Signature must match UID 9's POSITIONAL call exactly:
              update(rgb, ego.pos[:2], ego.yaw, ego.pos[2], tof)
        An earlier ordering here silently bound tof to the yaw argument, which would
        have produced a plausible-looking but wrong heading with no error raised."""
        try:
            xy, yaw, sigma, mode_w, disagree = self._predict(rgb)
        except Exception:
            self._count = 0
            self._last = _Result(None, False, math.inf, "predict_failed", 0)
            return self._last

        finite = bool(np.isfinite(xy).all() and math.isfinite(yaw) and math.isfinite(sigma))
        eligible = bool(finite and sigma <= SIGMA_MAX
                        and mode_w >= MODE_WEIGHT_MIN
                        and disagree <= DISAGREE_MAX)
        self._count = self._count + 1 if eligible else 0
        certified = eligible and self._count >= self.consecutive_required

        # heading_offset is the rotation from the dead-reckoning frame to the world
        # frame -- NOT the drone's yaw. UID 9 feeds it to f[18]/f[19] as sin/cos, the
        # same slot UID 17 fills from loc.theta().
        heading = float(yaw - float(ego_yaw))
        heading = math.atan2(math.sin(heading), math.cos(heading))

        # Report the spread the caller gates on. Uncertified frames are given a
        # spread ABOVE their 0.35 m threshold so their own check rejects them and the
        # native particle filter is used instead -- we never silently override it.
        spread = float(sigma) if certified else 9.0
        post = _Posterior(finite, np.asarray(xy, np.float64), spread, heading,
                          mode_w, float(sigma))
        risk = sigma + 2.0 * (1.0 - mode_w) + 2.0 * disagree
        self._last = _Result(post, certified, risk,
                             "certified" if certified else "risk", self._count)
        return self._last




import os
import sys

import numpy as np

_HERE_DIR = os.path.dirname(os.path.abspath(__file__))
if _HERE_DIR not in sys.path:
    sys.path.insert(0, _HERE_DIR)


_DEFAULT_PATH = os.path.join(_HERE_DIR,
                             "office_grid.npz")


TOF_RAY_OFFSET = 0.11
TOF_NO_HIT = 100.0


class OfficeGrid:

    def __init__(self, path: str = _DEFAULT_PATH):
        with np.load(path) as d:
            self.shape = tuple(int(v) for v in d["shape"])
            self.res = float(d["res"])
            self.origin = np.asarray(d["origin"], dtype=np.float64)
            nz, ny, nx = self.shape
            total = nz * ny * nx
            self.surface = (
                np.unpackbits(d["surface_bits"])[:total]
                .reshape(self.shape)
                .astype(bool)
            )
            self.clear_cm = d["clear_cm"]
            self.col_top = d["col_top"]
            self.surf_mm = d["surf_mm"]
        self._nz, self._ny, self._nx = self.shape


    def _prep(self, xyz):
        pts = np.asarray(xyz, dtype=np.float64)
        single = pts.ndim == 1
        pts = np.atleast_2d(pts)
        return pts, single

    def _cell(self, pts):
        rel = (pts - self.origin[None, :]) / self.res
        idx = np.floor(rel).astype(np.int64)
        return idx[:, 0], idx[:, 1], idx[:, 2]


    def clearance(self, xyz):
        pts, single = self._prep(xyz)
        i, j, k = self._cell(pts)
        inb = (
            (i >= 0) & (i < self._nx)
            & (j >= 0) & (j < self._ny)
            & (k >= 0) & (k < self._nz)
        )
        ic = np.where(inb, i, 0)
        jc = np.where(inb, j, 0)
        kc = np.where(inb, k, 0)
        out = np.where(
            inb, self.clear_cm[kc, jc, ic].astype(np.float64) * 0.01, 0.0
        )
        return float(out[0]) if single else out

    def predict_tof(self, xyz):
        pts, single = self._prep(xyz)
        x, y, z = pts[:, 0], pts[:, 1], pts[:, 2]
        z_start = z - TOF_RAY_OFFSET
        i = np.floor((x - self.origin[0]) / self.res).astype(np.int64)
        j = np.floor((y - self.origin[1]) / self.res).astype(np.int64)
        k = np.floor((z_start - self.origin[2]) / self.res).astype(np.int64)
        inb = (
            (i >= 0) & (i < self._nx)
            & (j >= 0) & (j < self._ny)
            & (k >= 0) & (k < self._nz)
        )
        ic = np.where(inb, i, 0)
        jc = np.where(inb, j, 0)
        kc = np.where(inb, k, 0)
        top = self.col_top[jc, ic, kc].astype(np.int64)
        hit = inb & (top >= 0)
        tc = np.where(hit, top, 0)
        z_surf = (
            self.origin[2]
            + tc.astype(np.float64) * self.res
            + self.surf_mm[tc, jc, ic].astype(np.float64) * 1e-3
        )
        out = np.where(hit, z - z_surf, TOF_NO_HIT)
        return float(out[0]) if single else out

    def path_clearance(self, a, b, samples: int = 0):
        a2, single = self._prep(a)
        b2, _ = self._prep(b)
        d = np.linalg.norm(b2 - a2, axis=1)
        if samples and samples > 0:
            n = max(2, int(samples))
        else:
            n = max(2, int(float(d.max()) / self.res) + 2)
        t = np.linspace(0.0, 1.0, n)
        pts = a2[:, None, :] + t[None, :, None] * (b2 - a2)[:, None, :]
        c = self.clearance(pts.reshape(-1, 3)).reshape(a2.shape[0], n)
        out = c.min(axis=1)
        return float(out[0]) if single else out


import math
from collections import deque

import numpy as np

DT = 1.0 / 50.0
SPEED = 3.0
DEAD_ZONE = 0.05
SLEW_STEP = 4.0 * DT
SPAWN_Z = 0.05


def body_to_world_xy(f: float, r: float, yaw: float) -> tuple[float, float]:
    c, s = math.cos(yaw), math.sin(yaw)
    return c * f + s * r, s * f - c * r


class EgoState:

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.t = 0.0
        self.yaw = 0.0
        self.pos = np.zeros(3)
        self.vel = np.zeros(3)
        self.rc = np.zeros(4)
        self._age_prev = 1e9
        self.have_fix = False
        self.hist: deque = deque(maxlen=256)


    def update(self, state: np.ndarray, last_action: np.ndarray) -> None:
        s = np.asarray(state, dtype=np.float64).reshape(-1)

        a = np.clip(np.asarray(last_action, dtype=np.float64).reshape(-1)[:4], -1, 1)
        a[np.abs(a) < DEAD_ZONE] = 0.0
        self.rc += np.clip(a - self.rc, -SLEW_STEP, SLEW_STEP)

        self.t += DT
        age, valid = float(s[13]), float(s[14])
        fresh = (valid > 0.5 and 0.0 <= age < self._age_prev - 1e-9
                 and np.isfinite(s[:15]).all())
        self._age_prev = age

        if fresh:
            self.yaw = math.atan2(float(s[2]), float(s[3]))
            self.have_fix = True

        vx, vy = body_to_world_xy(float(s[4]), float(s[5]), self.yaw)
        vz = -float(s[6])
        self.vel = np.array([vx, vy, vz])

        self.pos[0] += vx * DT
        self.pos[1] += vy * DT
        self.pos[2] = float(s[11]) + SPAWN_Z + vz * age
        self.hist.append((self.t, self.pos[0], self.pos[1]))


    def xy_at(self, t_query: float) -> np.ndarray:
        if not self.hist:
            return self.pos[:2].copy()
        h = self.hist
        if t_query <= h[0][0]:
            return np.array([h[0][1], h[0][2]])
        prev = h[0]
        for entry in h:
            if entry[0] >= t_query:
                t0, x0, y0 = prev
                t1, x1, y1 = entry
                if t1 - t0 < 1e-9:
                    return np.array([x1, y1])
                a = (t_query - t0) / (t1 - t0)
                return np.array([x0 + a * (x1 - x0), y0 + a * (y1 - y0)])
            prev = entry
        return self.pos[:2].copy()

    def vcmd_world(self) -> np.ndarray:
        vx, vy = body_to_world_xy(self.rc[1] * SPEED, self.rc[0] * SPEED, self.yaw)
        return np.array([vx, vy, self.rc[2] * SPEED])


import math

import numpy as np

HULL = 0.16
TOF_SIGMA = 0.13
TOF_OUTLIER = 0.35
ALIVE_FLOOR = 0.02
DRIFT_PER_M = 0.012
ROUGHEN_XY = 0.06
ROUGHEN_TH = 0.02
SEED_Z = 1.5
START_Z = 0.8
SEED_MARGIN = 0.35
SELF_FREE_M = 0.35
SELF_FREE_R = 0.12
CONVERGED_SPREAD = 0.35


class GridLocalizer:
    def __init__(self, grid, n: int = 4096, seed: int = 0):
        self.grid = grid
        self.n = int(n)
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self) -> None:
        self.seeded = False
        self.p = np.zeros((self.n, 2))
        self.th = np.zeros(self.n)
        self.cth = np.ones(self.n)
        self.sth = np.zeros(self.n)
        self.w = np.full(self.n, 1.0 / self.n)
        self.anchor = np.zeros(2)
        self._free_anchor: np.ndarray | None = None
        self.converged = False


    def _seed(self, dr_xy: np.ndarray) -> None:
        g = self.grid
        nz, ny, nx = [int(v) for v in g.shape]
        lo = np.asarray(g.origin[:2]) + SEED_MARGIN
        hi = (np.asarray(g.origin[:2])
              + np.asarray([nx, ny]) * g.res - SEED_MARGIN)
        pts = []
        need = self.n
        for _ in range(24):
            cand = self.rng.uniform(lo, hi, (need * 2, 2))
            z = np.full((cand.shape[0], 1), SEED_Z)
            ok = g.clearance(np.hstack([cand, z])) > HULL
            pts.append(cand[ok])
            if sum(len(x) for x in pts) >= self.n:
                break
        cloud = np.vstack(pts)[: self.n]
        if cloud.shape[0] < self.n:
            extra = self.rng.uniform(lo, hi, (self.n - cloud.shape[0], 2))
            cloud = np.vstack([cloud, extra])
        self.p = cloud
        self.th = self.rng.uniform(0.0, 2 * math.pi, self.n)
        self.cth, self.sth = np.cos(self.th), np.sin(self.th)
        self.w = np.full(self.n, 1.0 / self.n)
        self.anchor = np.asarray(dr_xy, dtype=float).copy()
        self.seeded = True
        self.converged = False


    def update(self, dr_xy: np.ndarray, z: float, tof: float,
               moved: float) -> None:
        if not self.seeded:
            if z >= START_Z:
                self._seed(dr_xy)
            return
        if z < START_Z:
            return
        d = np.asarray(dr_xy, dtype=float) - self.anchor
        self.anchor = np.asarray(dr_xy, dtype=float).copy()
        self.p[:, 0] += self.cth * d[0] - self.sth * d[1]
        self.p[:, 1] += self.sth * d[0] + self.cth * d[1]
        if moved > 0:
            sig = DRIFT_PER_M * moved + 1e-4
            self.p += self.rng.normal(0.0, sig, self.p.shape)

        pts = np.hstack([self.p, np.full((self.n, 1), z)])
        like = np.where(self.grid.clearance(pts) > HULL, 1.0, ALIVE_FLOOR)
        if 0.0 < tof < 50.0:
            r = np.abs(self.grid.predict_tof(pts) - tof)
            like = like * ((1 - TOF_OUTLIER) * np.exp(-0.5 * (r / TOF_SIGMA) ** 2)
                           + TOF_OUTLIER)
        self._reweigh(like)

    def observe_self_free(self, a_xyz: np.ndarray, b_xyz: np.ndarray) -> None:
        if not self.seeded:
            return
        a = np.asarray(a_xyz, dtype=float)
        b = np.asarray(b_xyz, dtype=float)
        n = float(np.linalg.norm(b[:2] - a[:2]))
        if n < 0.15 or n > 4.0:
            return
        k = max(3, int(n / 0.25) + 1)
        ts = np.linspace(0.0, 1.0, k)
        seg = a[None, :] + ts[:, None] * (b - a)[None, :]
        da = seg[:, :2] - self.anchor[None, :]

        px = (self.p[:, 0, None] + self.cth[:, None] * da[None, :, 0]
              - self.sth[:, None] * da[None, :, 1])
        py = (self.p[:, 1, None] + self.sth[:, None] * da[None, :, 0]
              + self.cth[:, None] * da[None, :, 1])
        pz = np.broadcast_to(seg[None, :, 2], px.shape)
        pts = np.stack([px, py, pz], axis=-1).reshape(-1, 3)
        clear = self.grid.clearance(pts).reshape(self.n, k)
        like = np.where(clear.min(axis=1) > SELF_FREE_R, 1.0, ALIVE_FLOOR)
        self._reweigh(like)

    def maybe_observe_self_free(self, pos_xyz: np.ndarray) -> None:
        if self._free_anchor is None:
            self._free_anchor = np.asarray(pos_xyz, dtype=float).copy()
            return
        d = float(np.linalg.norm(pos_xyz[:2] - self._free_anchor[:2]))
        if d >= SELF_FREE_M:
            self.observe_self_free(self._free_anchor, pos_xyz)
            self._free_anchor = np.asarray(pos_xyz, dtype=float).copy()


    def _reweigh(self, like: np.ndarray) -> None:
        w = self.w * like
        tot = float(w.sum())
        if not np.isfinite(tot) or tot <= 0.0:
            self.seeded = False
            self.converged = False
            return
        self.w = w / tot
        ess = 1.0 / float((self.w ** 2).sum())
        if ess < 0.5 * self.n:
            self._resample()
        self.converged = self.spread() < CONVERGED_SPREAD

    def _resample(self) -> None:
        cum = np.cumsum(self.w)
        cum[-1] = 1.0
        pos = (self.rng.random() + np.arange(self.n)) / self.n
        idx = np.searchsorted(cum, pos)
        self.p = self.p[idx] + self.rng.normal(0.0, ROUGHEN_XY, (self.n, 2))
        self.th = self.th[idx] + self.rng.normal(0.0, ROUGHEN_TH, self.n)
        self.cth, self.sth = np.cos(self.th), np.sin(self.th)
        self.w = np.full(self.n, 1.0 / self.n)


    def stats_at(self, dr_xy: np.ndarray):
        if not self.seeded:
            return np.zeros(2), 99.0
        d = np.asarray(dr_xy, dtype=float) - self.anchor
        px = self.p[:, 0] + self.cth * d[0] - self.sth * d[1]
        py = self.p[:, 1] + self.sth * d[0] + self.cth * d[1]
        mx = float((self.w * px).sum())
        my = float((self.w * py).sum())
        sp = float(np.sqrt((self.w * ((px - mx) ** 2 + (py - my) ** 2)).sum()))
        return np.array([mx, my]), sp

    def spread(self) -> float:
        return self.stats_at(self.anchor)[1]

    def theta(self) -> float:
        if not self.seeded:
            return 0.0
        return float(math.atan2((self.w * self.sth).sum(),
                                (self.w * self.cth).sum()))

    def theta_conf(self) -> float:
        if not self.seeded:
            return 0.0
        return float(np.hypot((self.w * self.sth).sum(),
                              (self.w * self.cth).sum()))


import math
from collections import deque

import numpy as np

DT = 1.0 / 50.0
RES = 256.0
K_TAN = 2.0
TGT_W, TGT_H = 0.18, 0.08
EYE_FWD, EYE_UP = 0.13, 0.05
ALPHA, BETA = 0.45, 0.35
ADAPT_REF = 1.5
GATE_K = 0.25
VT_MAX = 2.4
VT_DECAY = 0.98
STALE_S = 0.45
FRESH_S = 0.30
CONFIRM_S = 0.35
Z_MIN, Z_MAX = 0.95, 3.00


def _derotate(f: float, left: float, up: float, pitch: float, roll: float):
    cp, sp = math.cos(pitch), math.sin(pitch)
    f1 = cp * f + sp * up
    u1 = -sp * f + cp * up
    cr, sr = math.cos(roll), math.sin(roll)
    l1 = cr * left - sr * u1
    u2 = sr * left + cr * u1
    return f1, l1, u2


class TargetTrack:
    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.t = 0.0
        self.rel: np.ndarray | None = None
        self.vt = np.zeros(3)
        self.age = 10.0
        self.confirmed = False
        self._confirm_t = -10.0
        self._meas_t = -10.0
        self._det_age_prev = 1e9
        self.att: deque = deque(maxlen=40)
        self.last_box = np.zeros(5)
        self.last_meas_rel: np.ndarray | None = None
        self.last_meas_t = -1.0


    @property
    def have(self) -> bool:
        return self.rel is not None and self.confirmed

    def fresh(self) -> bool:
        return self.have and self.age < FRESH_S

    def usable(self) -> bool:
        return self.have and self.age < STALE_S


    def _att_at(self, t_eff: float):
        best = None
        for entry in self.att:
            if best is None or abs(entry[0] - t_eff) < abs(best[0] - t_eff):
                best = entry
        return best[1:] if best else (0.0, 0.0, 0.0)

    def _box_to_rel(self, box: np.ndarray, det_age: float, z_self: float):
        cx, cy, w, h, _conf = [float(v) for v in box]
        if w < 1e-6 or h < 1e-6:
            return None
        depth = math.sqrt((TGT_W / (w * K_TAN)) * (TGT_H / (h * K_TAN)))
        a = (cx - 0.5) * K_TAN
        b = (cy - 0.5) * K_TAN
        pitch, roll, yaw = self._att_at(self.t - det_age)
        f, left, up = _derotate(depth + EYE_FWD, -a * depth, -b * depth + EYE_UP,
                                pitch, roll)
        c, s = math.cos(yaw), math.sin(yaw)
        rel = np.array([c * f - s * left, s * f + c * left, up])
        if not (Z_MIN <= z_self + rel[2] <= Z_MAX):
            return None
        return rel


    def update(self, state: np.ndarray, v_self: np.ndarray, yaw: float,
               z_self: float) -> None:
        s = np.asarray(state, dtype=np.float64).reshape(-1)
        self.t += DT
        self.att.append((self.t - float(s[13]), float(s[0]), float(s[1]), yaw))
        self.age += DT
        if self.rel is not None:
            self.rel = self.rel + (self.vt - v_self) * DT
            if self.age > STALE_S:
                self.vt = self.vt * VT_DECAY
        n_boxes = int(round(float(s[15])))
        det_age = float(s[16])
        fresh_block = det_age < self._det_age_prev - 1e-9
        self._det_age_prev = det_age
        if n_boxes <= 0 or not fresh_block:
            if self.age > 4.0:
                self.rel, self.confirmed = None, False
            return

        held = self.rel if self.age < STALE_S else None
        best, best_cost = None, None
        for k in range(min(n_boxes, 2)):
            box = s[17 + 5 * k: 22 + 5 * k]
            rel = self._box_to_rel(box, det_age, z_self)
            if rel is None:
                continue
            rel = rel - v_self * det_age
            if held is not None:
                cost = float(np.linalg.norm(rel - held))
                if cost > max(1.0, GATE_K * float(np.linalg.norm(held))):
                    continue
            else:
                cost = 4.0 - float(box[4])
            if best_cost is None or cost < best_cost:
                best, best_cost = (rel, box), cost
        if best is None:
            return
        rel_meas, box = best
        self.last_box = np.asarray(box, dtype=np.float64).copy()
        self.last_meas_rel = rel_meas.copy()
        self.last_meas_t = self.t

        if self.rel is None or self.age >= STALE_S:
            self.rel = rel_meas
            self.vt = np.zeros(3)
            self.confirmed = (self.t - self._confirm_t) <= CONFIRM_S
        else:
            dt_m = max(self.t - self._meas_t, DT)
            err = rel_meas - self.rel
            r = float(np.linalg.norm(self.rel))
            g = 2.0 * ADAPT_REF ** 2 / (ADAPT_REF ** 2 + r * r)
            ka = float(np.clip(ALPHA * g, 0.15, 0.90))
            kb = float(np.clip(BETA * g, 0.08, 0.75))
            self.rel = self.rel + ka * err
            self.vt = self.vt + (kb / dt_m) * err
            n = float(np.linalg.norm(self.vt))
            if n > VT_MAX:
                self.vt *= VT_MAX / n
            self.confirmed = True
        self._confirm_t = self._meas_t = self.t
        self.age = 0.0


import math

import numpy as np

R_TERMINAL = 1.5
A_MAX_TGT = 2.0
N_TERMINAL = 10


class TerminalEstimator:
    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self._blind_t = 0.0
        self._prev_az = None
        self._bearing_rate = 0.0
        self._r_hat: np.ndarray | None = None
        self._meas_t_seen = -1.0

    def features(self, track, ego, det_age: float, dt: float) -> np.ndarray:
        f = np.zeros(N_TERMINAL, dtype=np.float32)
        if track.rel is None or not track.have:
            self._blind_t = 0.0
            self._prev_az = None
            return f


        if (track.last_meas_rel is not None
                and track.last_meas_t > self._meas_t_seen):
            self._r_hat = np.asarray(track.last_meas_rel, dtype=np.float64).copy()
            self._meas_t_seen = track.last_meas_t
        elif self._r_hat is not None:
            self._r_hat = self._r_hat + (np.asarray(track.vt)
                                         - np.asarray(ego.vel)) * dt
        r = (self._r_hat if self._r_hat is not None
             else np.asarray(track.rel, dtype=np.float64))
        rng = float(np.linalg.norm(r))
        in_term = rng < R_TERMINAL

        if in_term and det_age > 0.15:
            self._blind_t += dt
        else:
            self._blind_t = 0.0

        v_rel = np.asarray(track.vt, dtype=np.float64) - np.asarray(ego.vel)
        sp2 = float(v_rel @ v_rel)
        cy, sy = math.cos(-ego.yaw), math.sin(-ego.yaw)

        def to_body(w):
            return np.array([cy * w[0] - sy * w[1],
                             sy * w[0] + cy * w[1], w[2]])

        closing = float(-(r @ v_rel) / max(rng, 1e-6))
        if sp2 > 1e-6:
            tgo = float(np.clip(-(r @ v_rel) / sp2, 0.0, 4.0))
        else:
            tgo = 4.0
        miss = r + v_rel * tgo
        miss_b = to_body(miss)
        az = math.atan2(r[1], r[0])
        if self._prev_az is not None:
            d = math.atan2(math.sin(az - self._prev_az),
                           math.cos(az - self._prev_az))
            self._bearing_rate = 0.7 * self._bearing_rate + 0.3 * (d / dt)
        self._prev_az = az

        f[0] = 1.0 if in_term else 0.0
        f[1] = tgo / 4.0
        f[2:5] = np.clip(miss_b, -3.0, 3.0)
        f[5] = min(float(np.linalg.norm(miss)), 3.0)
        f[6] = float(np.clip(closing, -3.0, 3.0)) / 3.0
        f[7] = min(self._blind_t, 2.0)
        f[8] = min(0.5 * A_MAX_TGT * self._blind_t ** 2, 2.0)
        f[9] = float(np.clip(self._bearing_rate, -4.0, 4.0)) / 4.0
        return f


import math

import numpy as np


STATE_DIM = 127
N_BASE_FEATURES = 52
N_FEATURES = N_BASE_FEATURES + N_TERMINAL
STACK_KEEP = 27
STACK_LEN = 10
BASE_ACTOR_DIM = STATE_DIM + N_BASE_FEATURES + STACK_KEEP * STACK_LEN
ACTOR_DIM = STATE_DIM + N_FEATURES + STACK_KEEP * STACK_LEN


_PROBE_R = 0.75
_PATH_REACH = 1.2


class FeatureBuilder:
    def __init__(self, grid=None, loc_particles: int = 4096, seed: int = 0):
        if grid is None:
            from .mapgrid import OfficeGrid
            grid = OfficeGrid()
        self.grid = grid
        self.ego = EgoState()
        self.track = TargetTrack()
        self.loc = GridLocalizer(grid, n=loc_particles, seed=seed)
        self.target_upgrade = CloseRangeConsensusEstimator()
        self.visual_shadow = None
        self.visual_last = None
        self.visual_disabled = False
        self.terminal = TerminalEstimator()
        self._stack = np.zeros((STACK_LEN, STACK_KEEP), dtype=np.float32)
        self._primed = False
        self._last_action = np.zeros(4)
        self._age_prev = 1e9

    def reset(self) -> None:
        self.ego.reset()
        self.track.reset()
        self.loc.reset()
        self.target_upgrade.reset()
        if self.visual_shadow is not None:
            self.visual_shadow.reset()
        self.visual_last = None
        self.visual_disabled = False
        self.terminal.reset()
        self._stack[:] = 0.0
        self._primed = False
        self._last_action = np.zeros(4)
        self._age_prev = 1e9

    def note_action(self, action: np.ndarray) -> None:
        self._last_action = np.asarray(action, dtype=np.float64).reshape(-1)[:4]


    def build(self, state: np.ndarray, rgb: np.ndarray | None = None) -> np.ndarray:
        s = np.asarray(state, dtype=np.float32).reshape(-1)
        live = s[:STACK_KEEP]
        if not self._primed:
            self._stack[:] = live[None, :]
            self._primed = True
        else:
            self._stack[:-1] = self._stack[1:]
            self._stack[-1] = live

        self.ego.update(s, self._last_action)
        ego = self.ego
        self.track.update(s, ego.vel, ego.yaw, float(ego.pos[2]))


        age, valid = float(s[13]), float(s[14])
        fresh = valid > 0.5 and 0.0 <= age < self._age_prev - 1e-9
        self._age_prev = age
        if fresh:
            dr_pkt = ego.xy_at(ego.t - age)
            z_pkt = float(s[11]) + SPAWN_Z
            moved = (float(np.linalg.norm(dr_pkt - self.loc.anchor))
                     if self.loc.seeded else 0.0)
            self.loc.update(dr_pkt, z_pkt, float(s[10]), moved)
        self.loc.maybe_observe_self_free(ego.pos)

        if (not self.visual_disabled and rgb is not None and ego.pos[2] >= 0.8):
            try:
                if self.visual_shadow is None:
                    self.visual_shadow = TemporalVisualShadow(
                        os.path.join(os.path.dirname(os.path.abspath(__file__)), "visual_pose.onnx"),
                        self.grid,
                        input_mode="mixed",
                        threads=2,
                        consecutive=2,
                    )
                tof = float(s[10]) if np.isfinite(s[10]) else None
                result = self.visual_shadow.update(
                    np.asarray(rgb),
                    ego.pos[:2].copy(),
                    float(ego.yaw),
                    float(ego.pos[2]),
                    tof,
                )
                self.visual_last = result
            except Exception:
                # The benchmark contract does not guarantee RGB availability;
                self.visual_disabled = True
                self.visual_last = None

        upgraded = self.target_upgrade.step(s)
        if upgraded.position_takeoff_m is not None and self.track.have:
            self.track.rel = np.asarray(upgraded.position_takeoff_m, dtype=np.float64).copy()

        term = self.terminal.features(self.track, self.ego, float(s[16]), DT)
        return np.concatenate(
            [s, self._features(s), self._stack.reshape(-1), term]
        ).astype(np.float32)


    def _features(self, s: np.ndarray) -> np.ndarray:
        f = np.zeros(N_BASE_FEATURES, dtype=np.float32)
        ego, track, loc = self.ego, self.track, self.loc

        visual_pose = None
        if self.visual_last is not None and self.visual_last.posterior is not None:
            posterior = self.visual_last.posterior
            if (posterior.finite and np.isfinite(posterior.xy).all()
                    and math.isfinite(float(posterior.mode_spread_m))
                    and posterior.mode_spread_m <= 0.35):
                visual_pose = posterior
        native_est, native_spread = loc.stats_at(ego.pos[:2])
        native_usable = loc.seeded and loc.converged and loc.theta_conf() > 0.5
        if visual_pose is not None:
            est = np.asarray(visual_pose.xy, dtype=np.float64)
            spread = float(visual_pose.mode_spread_m)
            th = float(visual_pose.heading_offset)
            pose_usable = True
        else:
            est = np.asarray(native_est, dtype=np.float64)
            spread = float(native_spread)
            th = loc.theta()
            pose_usable = native_usable

        f[0] = ego.pos[0] / 10.0
        f[1] = ego.pos[1] / 10.0
        f[2] = ego.pos[2] / 3.0
        f[3] = math.sin(ego.yaw)
        f[4] = math.cos(ego.yaw)
        f[5:8] = ego.vel / 3.0
        f[8:12] = ego.rc
        f[12:15] = ego.vcmd_world() / 3.0


        f[15] = est[0] / 10.0
        f[16] = est[1] / 10.0
        f[17] = min(spread, 3.0)
        f[18] = math.sin(th)
        f[19] = math.cos(th)
        f[20] = loc.theta_conf()
        f[21] = 1.0 if pose_usable else 0.0


        usable = pose_usable
        if usable:
            c, s_ = math.cos(th), math.sin(th)
            z = float(ego.pos[2])
            pos_m = np.array([est[0], est[1], z])
            vc = ego.vcmd_world()
            hd = vc[:2]
            n = float(np.linalg.norm(hd))
            u = hd / n if n > 1e-6 else np.array(
                [math.cos(ego.yaw), math.sin(ego.yaw)])
            um = np.array([c * u[0] - s_ * u[1], s_ * u[0] + c * u[1]])
            left = np.array([-um[1], um[0]])
            probes = np.array([
                pos_m,
                pos_m + np.array([um[0], um[1], 0.0]) * _PROBE_R,
                pos_m + np.array([left[0], left[1], 0.0]) * _PROBE_R,
                pos_m - np.array([left[0], left[1], 0.0]) * _PROBE_R,
            ])
            cl = self.grid.clearance(probes)
            f[22:26] = np.minimum(cl, 2.0)
            f[26] = min(self.grid.path_clearance(
                pos_m, pos_m + np.array([um[0], um[1], 0.0]) * _PATH_REACH), 2.0)
            tof_pred = float(np.atleast_1d(self.grid.predict_tof(pos_m[None, :]))[0])
            f[27] = float(np.clip(tof_pred - float(s[10]), -1.0, 1.0))
            f[28] = 1.0

        if track.rel is not None:
            rel = track.rel
            cy, sy = math.cos(-ego.yaw), math.sin(-ego.yaw)
            rb = np.array([cy * rel[0] - sy * rel[1],
                           sy * rel[0] + cy * rel[1], rel[2]])
            rng = float(np.linalg.norm(rel))
            az = math.atan2(rb[1], rb[0])
            f[29] = 1.0 if track.have else 0.0
            f[30] = 1.0 if track.fresh() else 0.0
            f[31:34] = rb / 10.0
            f[34] = rng / 10.0
            f[35] = math.sin(az)
            f[36] = math.cos(az)
            f[37] = math.atan2(rb[2], max(math.hypot(rb[0], rb[1]), 1e-6))
            f[38:41] = track.vt / 3.0
            if rng > 1e-6:
                f[41] = float(np.dot(track.vt, rel) / rng) / 3.0
            f[42] = min(track.age, 5.0)
            f[43] = float(np.linalg.norm(track.vt)) / 3.0
        else:
            f[42] = 5.0


        f[44] = s[15]
        f[45] = s[16]
        f[46:51] = track.last_box
        f[51] = min(self.ego.t, 60.0) / 60.0
        return f


import numpy as _np
import torch as _torch
import torch.nn as _nn
from pathlib import Path as _Path

_torch.set_num_threads(1)
_HERE = _Path(__file__).resolve().parent
_HIDDEN = (1024, 1024, 1024)
_NORM_DIM = 449


def _mlp(sizes):
    layers = []
    for a, b in zip(sizes[:-1], sizes[1:]):
        layers += [_nn.Linear(a, b), _nn.SiLU()]
    return _nn.Sequential(*layers)


class _Actor(_nn.Module):
    def __init__(self):
        super().__init__()
        self.norm = _nn.LayerNorm(_NORM_DIM)
        self.trunk = _mlp((ACTOR_DIM, *_HIDDEN))
        self.mean = _nn.Linear(_HIDDEN[-1], 4)
        self.log_std = _nn.Parameter(_torch.zeros(4))

    def forward(self, x):
        h = _torch.cat([self.norm(x[..., :_NORM_DIM]), x[..., _NORM_DIM:]], -1)
        return _torch.tanh(self.mean(self.trunk(h)))


class DroneFlightController:
    def __init__(self):
        grid = OfficeGrid(str(_HERE / "office_grid.npz"))
        self._features = FeatureBuilder(grid=grid, loc_particles=4096)
        self._actor = _Actor()
        sd = _torch.load(_HERE / "office_actor.pt", map_location="cpu",
                         weights_only=True)
        self._actor.load_state_dict(sd)
        self._actor.eval()
        self._last = _np.zeros(4, dtype=_np.float32)
        with _torch.inference_mode():
            self._actor(_torch.zeros(1, ACTOR_DIM))

    def reset(self):
        self._features.reset()
        self._last = _np.zeros(4, dtype=_np.float32)

    def act(self, observation):
        state = _np.array(observation["state"], dtype=_np.float32).reshape(-1)
        if state.shape[0] != 127:
            fixed = _np.zeros(127, dtype=_np.float32)
            fixed[:min(127, state.shape[0])] = state[:127]
            state = fixed
        x = self._features.build(state, observation.get("rgb"))
        with _torch.inference_mode():
            a = self._actor(_torch.from_numpy(x).unsqueeze(0)).squeeze(0).numpy()
        a = _np.nan_to_num(a, nan=0.0).astype(_np.float32)
        self._features.note_action(a)
        self._last = a
        return a

